<?php
		require_once("../public/functions.php");
		

		$totaldbcount = mysql_query("select count(*) as count from  asset a left join location c on 
        a.Loc=c.id left join asset_user d on 
        a.A_User=d.E_Id 
		left join department deprt ON a.Depart = deprt.Department_Id
		left join main_block e on 
        a.Block=e.Block_Id left join sub_block f on 
        a.Sub_Block=f.Subblock_Id where a.Status='NA' and a.Asset_Comp = '$company'");

       $allAsset = mysql_fetch_array($totaldbcount);

	//    $current_start_date=date("Y-m-d");
	//    $current_end_date=date("Y-m-d");

	//    $count_current_date_asset = mysql_query("select count(*) as count from  asset a left join location c on 
    //             a.Loc=c.id left join asset_user d on 
    //             a.A_User=d.E_Id left join main_block e on 
    //             a.Block=e.Block_Id left join sub_block f on 
    //             a.Sub_Block=f.Subblock_Id where a.Status='NA' and a.Asset_Comp = '$company' and (DATE_FORMAT(a.Created_Date,'%Y-%m-%d') >= '$current_start_date' and DATE_FORMAT(a.Created_Date,'%Y-%m-%d') <= '$current_end_date')");


	//    $currentAsset = mysql_fetch_array($count_current_date_asset);	
		

		if ((((empty($_REQUEST['startDate'])) && (!empty($_REQUEST['endDate'])))) || ((!empty($_REQUEST['startDate'])) && (empty($_REQUEST['endDate']))))
			{
				if(empty($_REQUEST['endDate']))
				{
					$Msg = "Please select a TO Date";
				}
				else if (empty($_REQUEST['startDate']))
				{
					$Msg = "Please select a From Date";
				}
			}
			else
			{
				
		if(!empty($_REQUEST['startDate']) || !empty($_REQUEST['endDate']))
		{
			$Ans_search = chk_data($_REQUEST['li_search']);
			//$Ans_search1 = chk_data($_REQUEST['startDate']);
			//$Ans_search2 = chk_data($_REQUEST['endDate']);
			$Ans_search1 = chk_data($_REQUEST['startDate']);
			$Ans_search2 = chk_data($_REQUEST['endDate']);
			//$Ans_search3 = chk_data($_REQUEST['startDate']);
			//$Ans_search4 = chk_data($_REQUEST['endDate']);
			
			$start_date = date_rev($Ans_search1);
	        $end_date = date_rev($Ans_search2);
			//echo $Ans_search;
			
			$count = mysql_query("select count(*) as count from  asset a left join location c on 
            a.Loc=c.id left join asset_user d on 
            a.A_User=d.E_Id 
			left join department deprt ON a.Depart = deprt.Department_Id
			left join main_block e on 
            a.Block=e.Block_Id left join sub_block f on 
            a.Sub_Block=f.Subblock_Id where a.Status='NA'  and a.Asset_Comp = '$company' and (DATE_FORMAT(a.Created_Date,'%Y-%m-%d') >= '$start_date' and DATE_FORMAT(a.Created_Date,'%Y-%m-%d') <= '$end_date')");
			
	
		}
		//Pagination without search result
		else
		{

				$current_start_date=date("Y-m-d");
				$current_end_date=date("Y-m-d");

				$count = mysql_query("select count(*) as count from  asset a left join location c on 
                a.Loc=c.id left join asset_user d on 
                a.A_User=d.E_Id
				left join department deprt ON a.Depart = deprt.Department_Id
				left join main_block e on 
				
                a.Block=e.Block_Id left join sub_block f on 
                a.Sub_Block=f.Subblock_Id where a.Status='NA' and a.Asset_Comp = '$company' and (DATE_FORMAT(a.Created_Date,'%Y-%m-%d') >= '$current_start_date' and DATE_FORMAT(a.Created_Date,'%Y-%m-%d') <= '$current_end_date')");

				
		}
		$total = mysql_fetch_array($count);
		$total = $total['count'];
		//echo $total;
		$perpage = 10;	
		$pages = ceil($total / $perpage) ;	
		//echo $pages;
		
		
		if(isset($_GET['pageno']))
		{
			$urldata = $_GET['pageno'];
		}
		else
		{
			//Modify URL to set pageno
			$url = $_SERVER['SCRIPT_NAME'];
			echo $url;
			//exit;
			echo "<script>";
				echo "location.replace('$url?pageno=1')";
			echo "</script>";
		
			$urldata = 1;
		}
		//$x & $y as limit in pagination
		$x = $urldata*$perpage - $perpage;
		$y = $perpage;
		//echo $y;

				if((!empty($_REQUEST['startDate'])) || (!empty($_REQUEST['endDate'])))
				{
					
						echo "<script>";
							//echo "location.replace('$url&pageno=1&li_search=$Ans_search')";
						echo "</script>"; 
						
					// if(!empty($_REQUEST['li_search']) && isset($_REQUEST['li_search']))
					// {
					// $Ans_search = chk_data($_REQUEST['li_search']);
					// $_SESSION['val_search']=$Ans_search;
					// }
					if(!empty($_REQUEST['startDate']))
					{
					$Ans_search1 = date_rev(chk_data($_REQUEST['startDate']));
					$_SESSION['val_search1']=$Ans_search1;
					}
					if(!empty($_REQUEST['endDate']))
					{
					$Ans_search2 = date_rev(chk_data($_REQUEST['endDate']));
					$_SESSION['val_search2']=$Ans_search2;
					}



						
							$result = mysql_query("select *,a.Created_Date as CreatedDate from asset a left join location c on 
							a.Loc=c.id left join asset_user d on 
							a.A_User=d.E_Id 
							left join department deprt ON a.Depart = deprt.Department_Id
							left join main_block e on 
							a.Block=e.Block_Id left join sub_block f on 
							a.Sub_Block=f.Subblock_Id left join categories g on 
							a.Category=g.Id left join sub_categories h on 
							a.Sub_Category=h.SubCat_Id where a.Status='NA' and a.Asset_Comp = '$company' 
							and (DATE_FORMAT(a.Created_Date,'%Y-%m-%d') >= '$start_date' and DATE_FORMAT(a.Created_Date,'%Y-%m-%d') <= '$end_date')
							ORDER BY a.Asset_Id DESC limit $x,$y");
						
                }
				else
				{

							$current_start_date=date("Y-m-d");
							$current_end_date=date("Y-m-d");

							$result = mysql_query("select *,a.Created_Date as CreatedDate from asset a left join location c on 
							a.Loc=c.id left join asset_user d on 
							a.A_User=d.E_Id left join main_block e on 
							a.Block=e.Block_Id left join department deprt 
							ON a.Depart = deprt.Department_Id
							left join sub_block f on 
							a.Sub_Block=f.Subblock_Id left join categories g on 
							a.Category=g.Id left join sub_categories h on 
							a.Sub_Category=h.SubCat_Id where a.Status='NA' and a.Asset_Comp = '$company'
							and (DATE_FORMAT(a.Created_Date,'%Y-%m-%d') >= '$current_start_date' and DATE_FORMAT(a.Created_Date,'%Y-%m-%d') <= '$current_end_date')
							ORDER BY a.Asset_Id DESC limit $x,$y");
					
				}

				
				echo '<div id = "tbldata">';

				echo '<div>';
				echo '<label ><b>Total Assets : </b>'.$allAsset['count'].'</label>';
				echo '<br/>';
				echo '<br/>';
				echo '<label style="margin-top:10px"><b>Current Date Assets : </b>'.$total.'</label>';
				echo '</div>';
				echo '<br/>';
				
				echo '<table id="viewAll" border="1px solid" cellpadding="5px">';
				echo '<tr>';
				//echo '<th>Id</th>';
                echo '<th>Asset Name</th>';
                echo '<th>Asset Code</th>';
                echo '<th>Asset Barcode</th>';
                echo '<th>Purchase Date</th>';
                echo '<th>Asset User</th>';
                echo '<th>Location</th>';
				echo '<th>Department</th>';
                echo '<th>Category</th>';
                echo '<th>Sub Category</th>';
			    echo '<th>Created Date / Current Date</th>';
				echo '</tr>';	
					
				while($data=mysql_fetch_assoc($result))
				
				{
					//pre($data);
					//exit;
					
					if($data['Purchase_Date']=='0000-00-00'){
						$Purchase_Date ='';
					}else{
						$Purchase_Date =chk_date($data['Purchase_Date']);
					}

					echo '<tr>
                    <td>'.$data['Asset_Name'].'</td>
                    <td>'.$data['Asset_Code'].'</td>
                    <td>'.$data['Asset_Barcode'].'</td>
                    <td>'.$Purchase_Date.'</td>
                    <td>'.$data['Asset_User'].'</td>
                    <td>'.$data['Location'].'</td>
					<td>'.$data['Department'].'</td>
                    <td>'.$data['Category_Type'].'</td>
                    <td>'.$data['Cat_Detail'].'</td>
					<td>'.chk_date($data['CreatedDate']).'</td>';

					echo '</tr>';
				}
				echo '</table>';
				//Current Page Name
				$thispage = "bulk_print.php";
				require_once("../public/report.php");
				echo '</div>';
				mysql_close($db);
			}
			?>