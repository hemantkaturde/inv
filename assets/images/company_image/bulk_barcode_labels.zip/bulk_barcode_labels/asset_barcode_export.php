<?php
require_once("../admin/access.php");
require_once("../public/functions.php");
$company = $_SESSION['log_comp'];


					
//Manually mention headings of the excel columns
if((!empty($_SESSION['val_search1'])) && (!empty($_SESSION['val_search2'])))
{
	$Ans_search1=$_SESSION['val_search1'];
	$Ans_search2=$_SESSION['val_search2'];
	

	  $sql3 = mysql_query("select Company_Name from company_master where Company_Id = '$company'");
							$ans_comp = mysql_fetch_assoc($sql3);
							$Ans_search3 =$ans_comp['Company_Name'];
	
	$fromDate = date("d-m-Y",strtotime($Ans_search1));
	$Todate = date("d-m-Y",strtotime($Ans_search2));
	
}
else
{	
  $sql3 = mysql_query("select Company_Name from company_master where Company_Id = '$company'");
							$ans_comp = mysql_fetch_assoc($sql3);
							$Ans_search3 =$ans_comp['Company_Name'];							
}

//Mysql query to get records from datanbase

	//echo $_SESSION['val_search'];



	$Ans_search1 = $_SESSION['val_search1'];
	$Ans_search2 = $_SESSION['val_search2']; 
	//echo $Ans_search;
	if((!empty($_SESSION['val_search1'])) && (!empty($_SESSION['val_search2'])))
	{

        $start_date = date_rev($Ans_search1);
	    $end_date = date_rev($Ans_search2);

		$sql = mysql_query("select *,a.Created_Date as CreatedDate,a.Remarks as Remarks from asset a left join location c on 
                                a.Loc=c.id left join asset_user d on 
                                a.A_User=d.E_Id 
                                left join department deprt ON a.Depart = deprt.Department_Id
                                left join main_block e on 
                                a.Block=e.Block_Id left join sub_block f on 
                                a.Sub_Block=f.Subblock_Id left join categories g on 
                                a.Category=g.Id left join sub_categories h on 
                                a.Sub_Category=h.SubCat_Id where a.Status='NA' and a.Asset_Comp = '$company' 
                                and (DATE_FORMAT(a.Created_Date,'%Y-%m-%d') >= '$start_date' and DATE_FORMAT(a.Created_Date,'%Y-%m-%d') <= '$end_date')
                                ORDER BY a.Asset_Id DESC");
	
	   $count_code = mysql_query("select count(*) as count from  asset a left join location c on 
                                    a.Loc=c.id 
                                    left join department deprt ON a.Depart = deprt.Department_Id
                                    left join asset_user d on 
                                    a.A_User=d.E_Id left join main_block e on 
                                    a.Block=e.Block_Id left join sub_block f on 
                                    a.Sub_Block=f.Subblock_Id where a.Status='NA'  and a.Asset_Comp = '$company' and (DATE_FORMAT(a.Created_Date,'%Y-%m-%d') >= '$start_date' and DATE_FORMAT(a.Created_Date,'%Y-%m-%d') <= '$end_date')");
	
	}else{



        $current_start_date=date("Y-m-d");
        $current_end_date=date("Y-m-d");

        $sql = mysql_query("select *,a.Created_Date as CreatedDate,a.Remarks as Remarks from asset a left join location c on 
                            a.Loc=c.id left join asset_user d on 
                            a.A_User=d.E_Id left join main_block e on 
                            a.Block=e.Block_Id 
                            left join department deprt ON a.Depart = deprt.Department_Id
                            left join sub_block f on 
                            a.Sub_Block=f.Subblock_Id left join categories g on 
                            a.Category=g.Id left join sub_categories h on 
                            a.Sub_Category=h.SubCat_Id where a.Status='NA' and a.Asset_Comp = '$company'
                            and (DATE_FORMAT(a.Created_Date,'%Y-%m-%d') >= '$current_start_date' and DATE_FORMAT(a.Created_Date,'%Y-%m-%d') <= '$current_end_date')
                            ORDER BY a.Asset_Id DESC");

                        
        $count_code = mysql_query("select count(*) as count from  asset a left join location c on 
                                a.Loc=c.id left join asset_user d on 
                                a.A_User=d.E_Id 
                                left join department deprt ON a.Depart = deprt.Department_Id
                                left join main_block e on 
                                a.Block=e.Block_Id left join sub_block f on 
                                a.Sub_Block=f.Subblock_Id where a.Status='NA' and a.Asset_Comp = '$company' and (DATE_FORMAT(a.Created_Date,'%Y-%m-%d') >= '$current_start_date' and DATE_FORMAT(a.Created_Date,'%Y-%m-%d') <= '$current_end_date')");				
                                                
   }

//echo $sql;
//get particular column data
function cleanData(&$str)
  {
    $str = preg_replace("/\t/", "\\t", $str);
    $str = preg_replace("/\r?\n/", "\\n", $str);
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
  }

  // filename for download
  $filename = "Asset Barcode Report ". date('d-m-Y') . ".xls";

  header("Content-Disposition: attachment; filename=\"$filename\"");
  header("Content-Type: application/vnd.ms-excel");
  

  $flag = false;
  //$result = mysql_query("SELECT * FROM amc ORDER BY Amc_Id") or die('Query failed!');
  while(false !== ($row = mysql_fetch_assoc($sql))) 
  {
    if(!$flag) {
      // display field/column names as first row
	  $Ans_search1=$_SESSION['val_search1'];
	  $Ans_search2=$_SESSION['val_search2'];
	  
	  
	  echo "\r\n";
	  echo "\t" ."\t"."\t"."\t".'Asset Barcode Report'. "\r\n";
	  echo "\t" ."\t"."\t"."\t".'Company  :'.$Ans_search3. "\r\n";
      echo "\r\n";
	  echo 'From Date:'.$fromDate. "\t" .'To Date:'.$Todate ."\r\n";
	  
      echo 'Asset Name'."\t".'Asset Code'."\t".'Asset Barcode'."\t".'Purchase Date'."\t".'Asset User'."\t".'Location'."\t".'Department'."\t".'Category'."\t".'Sub Category'."\t".'Remark'."\t".'Created Date / Current Date'."\n";
	  //echo 'Asset Name'."\t".'Asset'."\t".'Code'."\t".'Location'."\t".'Document No'."\t".'Document'. "\t".'Date'."\t".'Service Provider'."\t".'Amc'."\t".'From'."\t".'Amc'."\t".'Upto'."\t".'Remark'."\n";
	   
	  //  echo "\t" ."\t"."\t"."\t"."\t"."\t".."\r\n";
      //  echo implode("\t", array_keys($row)) . "\r\n";
      $flag = true;
    }
    array_walk($row, 'cleanData');
    //echo implode("\t", array_values($row)) . "\r\n";

    if($data['Purchase_Date']=='0000-00-00'){
        $Purchase_Date ='';
    }else{
        $Purchase_Date =chk_date($data['Purchase_Date']);
    }
    echo $row['Asset_Name']."\t".$row['Asset_Code']."\t".$row['Asset_Barcode']."\t".$Purchase_Date."\t".$row['Asset_User']."\t".$row['Location']."\t".$row['Department']."\t".$row['Category_Type']."\t".$row['Cat_Detail']."\t".$row['Remarks']."\t".chk_date($row['CreatedDate'])."\r\n";
  }
   $ans_count = mysql_fetch_assoc($count_code);
		
	if($ans_count['count'] <= 0)
	{
		
	  echo "\r\n";
	  echo "\t" ."\t"."\t"."\t".'Asset Barcode Report'. "\r\n";
	  echo "\t" ."\t"."\t"."\t".'Company  :'.$Ans_search3. "\r\n";
      echo "\r\n";
	  echo 'From Date:'.$fromDate. "\t" .'To Date:'.$Todate ."\r\n";
    echo 'Asset Name'."\t".'Asset Code'."\t".'Asset Barcode'."\t".'Purchase Date'."\t".'Asset User'."\t".'Location'."\t".'Department'."\t".'Category'."\t".'Sub Category'."\t".'Remark'."\t".'Created Date / Current Date'."\n";
	}
  exit;
?>