<?php 

define('CLASS_PATH','../'); 
require_once('functions.php'); 
require_once(CLASS_PATH.'tcpdf/tcpdf.php'); 
require_once(CLASS_PATH."/label/class.label.php"); 
require_once(CLASS_PATH."label/class.labelCab.php"); 

$db = mysql_connect('localhost', 'quickass_demo', 'Qelocity@420');
        if(!$db)
		{
			die('Could not connect:' . mysql_error());
		}
		mysql_select_db('asset', $db) or die (mysql_error());

// $current_start_date=date("Y-m-d");
// $current_end_date=date("Y-m-d");
	
// $current_asset = mysql_query("SELECT * FROM asset WHERE Date(asset.Created_Date) >= '$current_start_date' and Date(asset.Created_Date) <= '$current_end_date' and Status='NA' and Asset_Comp='$company'");

// $data_current_asset = mysql_fetch_assoc($current_asset);

// if($data_current_asset){

      
$startDate = $_POST['startDate'];
$endDate = $_POST['endDate'];

$Ans_search1 = date_rev($startDate);
$Ans_search2 = date_rev($endDate);

// get company detals

$company_data = mysql_query("SELECT * FROM company_master  WHERE Status='A' and Company_Id='$company'");
$company_info= mysql_fetch_assoc($company_data);

$getfirstCharofeachword = explode(" ", $company_info['Company_Name']);
$company_firstchar = "";

foreach ($getfirstCharofeachword as $w) {
  $company_firstchar .= $w[0];
}


// select form asset table		  
if(empty ($startDate) && empty ($startDate))
{

	$current_start_date=date("Y-m-d");
	$current_end_date=date("Y-m-d");

    $sql1 = mysql_query("SELECT * FROM asset 
                                LEFT JOIN inward 
								ON asset.Inward_Type = inward.Id 
								LEFT JOIN location
								ON asset.Loc = location.id   
								LEFT JOIN department ON asset.Depart = department.Department_Id LEFT JOIN categories
							    ON asset.Category = categories.Id
                                WHERE Date(asset.Created_Date) >= '$current_start_date' and Date(asset.Created_Date) <= '$current_end_date' 
					            and asset.Status='NA' and asset.Asset_Comp='$company'");
								 
}	
else
{
   $sql1 = mysql_query("SELECT * FROM asset 
						LEFT JOIN inward 
						ON asset.Inward_Type = inward.Id 
						LEFT JOIN location
						ON asset.Loc = location.id   
						LEFT JOIN department
						ON asset.Depart = department.Department_Id LEFT JOIN categories
						ON asset.Category = categories.Id
                        where Date(asset.Created_Date) >= '$Ans_search1' and Date(asset.Created_Date) <= '$Ans_search2' 
					    and asset.Status='NA' and asset.Asset_Comp='$company'");								 
}


if (mysql_num_rows($sql1) != 0){

$data = array();


while($data1 = mysql_fetch_assoc($sql1))
{
$count = $data1['count'];
$code = $data1['Asset_Barcode'];
$department = $data1['Department'];
$Category_Type = $data1['Category_Type'];
$inword_type = $data1['Type'];

$info = array('cab' => $code,'company_name'=>strtoupper($company_firstchar),'typeCAB'=> 'C128B','department'=>$department,'Category_Type'=>$Category_Type,'inword_type'=>$inword_type);   
array_push($data,$info); 

}

/* $info = array('cab'=>$code, 'typeCAB'=>'C128B',); */
/* for ($j=0; $j < 5; $j++){ 
      array_push($data,$info); 
      }  */
	  
// hardcoded label id form xaml document
$label_id = 6; 

// Creation de l'objet label 
$pdf = new labelCab( $label_id, $data , CLASS_PATH.'label/', '', true); 

// Afficher les bordures 
$pdf->border = true; 

/* 
echo "<pre>"; 
print_r($data); 
echo "</pre>"; 
*/ 
$pdf->SetCreator(PDF_CREATOR); 
$pdf->SetAuthor('Barcode label'); 
$pdf->SetTitle("Barcode label"); 
$pdf->SetSubject("Barcode label"); 

// remove default header/footer 
$pdf->setPrintHeader(false); 
$pdf->setPrintFooter(false); 

$pdf->SetHeaderMargin(0); 
$pdf->SetFooterMargin(0); 

$pdf->SetAutoPageBreak( true, 0); 

//set image scale factor 
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);   

/*************************/ 
// Création 
$pdf->Addlabel(); 
/************************/ 
// Affichage 
$pdf->Output("Barcode label .pdf", "I"); 

}else{
	echo "<script type=\"text/javascript\">
							alert(\"No data Found\");
							window.location = '../bulk_print.php'
	</script>";
}	

?>