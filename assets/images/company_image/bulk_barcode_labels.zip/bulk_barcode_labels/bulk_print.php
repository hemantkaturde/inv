<?php
	require_once("../admin/access.php");
	require_once("../admin/header.php");
	require_once("../public/functions.php");
	error_reporting(0);
	js('report');
	css('jquery-ui');
	js('jquery-1.9.1');
	js('jquery-ui');

?>
<script>
    $(function() {
        $( "#startDate" ).datepicker({
            defaultDate:new Date(),
			dateFormat:('dd-mm-yy'),
            changeMonth: true,
			changeYear:true,
            <!-- numberOfMonths: 1, -->
            onClose: function( selectedDate ) {
                $( ".endDate" ).datepicker( "option", "minDate", selectedDate );
            }
        });
        $( ".endDate" ).datepicker({
            defaultDate: new Date(),
			dateFormat:('dd-mm-yy'),
            changeMonth: true,
			changeYear:true,
            <!-- numberOfMonths: 1, -->
            onClose: function( selectedDate ) {
                $( "#startDate" ).datepicker( "option", "maxDate", selectedDate );
            }
        });
    });
    </script>

<form id="formdata" class="formdata" action = "label/barcode_label.php" method = "post" target="_blank" >
	<ul>

		<li><label class="form_label">BulK Barcode Lables<label></li>
		<hr />
             <label for="startDate">From Date</label>
			<input type="text" id="startDate" name="startDate" />&emsp;&emsp;&emsp;<label for="endDate">To Date</label>
			<input type="text" class="endDate" name="endDate" /></div>
            <li><input type = "hidden" name = "li_url" value = "bulk_print_report.php?pageno=1" id = "li_url" /></li>
			<li><input type = "button" id = "u_btn" value = "SEARCH" class="frm_btn"/></li>			
	    </ul>

        <div>
       <?php 
       ?> 
      
       </div>
        <div id = "asset_table">
        </div>

 <?php
    include("bulk_print_report.php");
?>
<A HREF="../session/bulk_print_session.php"><input type = "button" value = "REFRESH" class="frm_btn"></A>
<input type='button' value='EXPORT TO EXCEL' class='frm_btn' onclick="location.href ='../bulk_barcode_labels/asset_barcode_export.php'">
<input type="submit" value="PRINT BARCODE" class="frm_btn"/>
<input type="button" value="CLOSE" class="frm_btn"onclick="location.href ='../admin/welcome.php'"/>

</form>
<?php
	require_once("../admin/footer.php");
?>
